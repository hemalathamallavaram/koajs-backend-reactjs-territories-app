module.exports = {
  db: "mongodb://localhost/overloop-techtest",
};
